package com.uberpets.library.fun;

public interface BiConsumer<A, B> {
    void accept(A a, B b);
}

