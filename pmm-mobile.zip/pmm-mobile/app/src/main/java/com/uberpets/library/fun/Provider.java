package com.uberpets.library.fun;

public interface Provider<T> {
    T get();
}
