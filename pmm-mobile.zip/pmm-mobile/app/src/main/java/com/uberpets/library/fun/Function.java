package com.uberpets.library.fun;

public interface Function<A, B> {
    B apply(A a);
}
