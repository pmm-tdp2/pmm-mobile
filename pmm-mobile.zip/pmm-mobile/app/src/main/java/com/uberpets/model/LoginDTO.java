package com.uberpets.model;

public class LoginDTO {
    private String id;

    public LoginDTO(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
