package com.uberpets.library.rest;

public class FileUpload {

}
