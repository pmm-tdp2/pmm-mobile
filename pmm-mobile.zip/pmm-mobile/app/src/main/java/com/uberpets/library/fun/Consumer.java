package com.uberpets.library.fun;

public interface Consumer<T> {
    void accept(T t);
}

